﻿using Microsoft.EntityFrameworkCore;
using ProductBacklogManagement.Models;
using ProductBacklogManagement_BLL.DTO;
using ProductBacklogManagement_BLL.Services.Interfaces;
using ProductBacklogManagement_DAL.Repository.Classes;
using ProductBacklogManagements_DAL.Repository.Classes;
using ProductBacklogManagements_DAL.Repository.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagement_BLL.Services.Classes
{
    public class UserStoryService : IUserStoryService
    {
        private readonly IUserStoryRepository userStoryRepo;
        private readonly IEpicRepository epicRepo;
        private readonly IEpicService epicService;

        public UserStoryService(IUserStoryRepository userStoryRepo, IEpicRepository epicRepo, IEpicService epicService)
        {
            this.userStoryRepo = userStoryRepo;
            this.epicRepo = epicRepo;
            this.epicService = epicService;
        }

        public async Task AddUserStoryAsync(UserStoryDTO userStoryDTO, int epicId)
        {
            var epic = await epicRepo.GetByIdAsync(epicId);
      

            if (epic != null)
            {
                ValidateUserStoryData(userStoryDTO);

                var userStory = new UserStory
                {
                    Title = userStoryDTO.Title,
                    UserStoryDetails = userStoryDTO.UserStoryDetails,
                    AcceptanceCriteria = userStoryDTO.AcceptanceCriteria,
                    Priority = userStoryDTO.Priority,
                    CreatedOn = DateTime.Today,
                    DoneOn = userStoryDTO.DoneOn,
                    AssignToDeveloperId = userStoryDTO.AssignToDeveloperId,
                    StoryPoints = userStoryDTO.StoryPoints,
                    Status = userStoryDTO.Status,
                    EpicId = epicId

                };
                await userStoryRepo.InsertUserStoryAsync(userStory);
            }
            else
            {
                throw new Exception("Epic Id doesn't exist.");
            }
            
        }

        public void ValidateUserStoryData(UserStoryDTO userStoryDTO)
        {
            if (string.IsNullOrEmpty(userStoryDTO.Title) || userStoryDTO.Title.Length < 5) //10
            {
                throw new Exception("User story title must be at least 10 letters.");
            }
            if (string.IsNullOrEmpty(userStoryDTO.UserStoryDetails) || userStoryDTO.UserStoryDetails.Split(' ').Length < 10)
            {
                throw new Exception("User story details must be at least 10 words."); //50
            }
            if (string.IsNullOrEmpty(userStoryDTO.AcceptanceCriteria) || userStoryDTO.AcceptanceCriteria.Split(' ').Length < 10)
            {
                throw new Exception("Acceptance criteria must be at least 10 words."); //50
            }
            if (string.IsNullOrEmpty(userStoryDTO.Priority) || userStoryDTO.Priority.Length > 2)
                {
                throw new Exception("Priority must be having less than 3 letters.");
            }

            var activeUserStories = userStoryRepo.GetAllUserStoryByDeveloperIdAsync(userStoryDTO.AssignToDeveloperId).Result.Where(u => u.Status != "Done");
            if (activeUserStories.Count() >= 5)
            {
                throw new Exception($"Developer {userStoryDTO.AssignToDeveloperId} already has 5 active user stories assigned.");
            }
            var allowedStatus = new[] { "New", "Planning", "Coding", "Testing", "Done" };
            if (!allowedStatus.Contains(userStoryDTO.Status))
            {
                throw new Exception("User story status must be one of the following values :" + string.Join(", ", allowedStatus));
            }

            if (userStoryDTO.StoryPoints < 1 || userStoryDTO.StoryPoints > 20)
            {
                throw new Exception("User story points must be in the range of 1-20.");
            }
        }


        public async Task CreateProductBackLogAsync(ProductBackLogDTO productBackLogDTO)
        {
            try
            {
                int id = await epicService.AddEpicAsync(productBackLogDTO.Epic);

                if (productBackLogDTO.UserStories != null && productBackLogDTO.UserStories.Any())
                {
                    await AddUserStoryByEpicIdAsync(productBackLogDTO.UserStories, id);
                }

            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while creating product backlog. " + ex.Message);
            }
        }

        public async Task AddUserStoryByEpicIdAsync(List<UserStoryDTO> userStoryDTOList, int epicId)
        {
            if (userStoryDTOList == null || userStoryDTOList.Count == 0)
            {
                throw new ArgumentNullException(nameof(userStoryDTOList), "Invalid Input Data.");
            }

            try
            {
                foreach (var userStoryDTO in userStoryDTOList)
                {
                    await AddUserStoryAsync(userStoryDTO, epicId);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while creating user story list. " + ex.Message);
            }
        }



        public async Task<UserStory> GetUserStoryByIdAsync(int userStoryId)
        {
            var userStory = await userStoryRepo.GetUserStoryByIdAsync(userStoryId);
            if (userStory == null)
            {
                throw new Exception("No user story assigned with the ID  " + userStoryId);
            }
            return userStory;

        }

       
        public async Task<UserStory> GetUserStoryByIdsAsync(int userStoryId, string developerId)
        {
            var userStory = await userStoryRepo.GetUserStoryByIdsAsync(userStoryId, developerId);
            if (userStory == null)
            {
                throw new Exception("No user story assigned to Developer " + developerId + "with the ID  " + userStoryId);
            }
            return userStory;

        }

        

        public async Task<List<UserStory>> GetAllUserStoriesByDeveloperIdAsync(string devId)
        {
            var userStories = await userStoryRepo.GetAllUserStoryByDeveloperIdAsync(devId);
            if(userStories.Count == 0)
            {
                throw new Exception($"Developer with ID:{devId} does not exists.");
            }
            return userStories;
        }


        public async Task<List<UserStory>> DisplayUserStoryByEpicIdAsync(int epicId)
        {
            var userStories = await userStoryRepo.GetAllUserStoryByEpicIdAsync(epicId);
            if (userStories.Count == 0)
            {
                throw new Exception($"Epic with ID:{epicId} does not have any user story");
            }
            return userStories;
        }



        public async Task UpdateUserStoryStatusAsync(UpdateStoryDTO updateStoryDTO)
        {
            var existingUserStory = await userStoryRepo.GetUserStoryByIdAsync(updateStoryDTO.UserStoryId);
            if (existingUserStory == null)
            {
                throw new ArgumentException($"User story with ID {updateStoryDTO.UserStoryId} does not exist in the database.");
            }
            else
            {
                var allowedStatus = new[] { "New", "Planning", "Coding", "Testing", "Done" };
                if (!allowedStatus.Contains(updateStoryDTO.Status))
                {
                    throw new ArgumentException($"User story status must be one of the following values: {string.Join(", ", allowedStatus)}.");
                }
            }
            await userStoryRepo.UpdateUserStoryStatusAsync(updateStoryDTO.UserStoryId, updateStoryDTO.Status);
        }



        public async Task<List<ProductBackLogReportDTO>> GetProductBacklogReportByProjectIdAsync(int projectId)
        {
            var epics = await epicRepo.GetEpicsByProjectIdAsync(projectId);
            
            var report = new List<ProductBackLogReportDTO>();

            foreach (var epic in epics)
            {
                if(epic.UserStories.Count == 0)
                {
                    throw new Exception($"No user stories exists for project id {projectId}");
                }
                foreach (var userStory in epic.UserStories)
                {
                    var existingEntry = report.FirstOrDefault(r => r.EpicName == epic.Name && r.Stage == userStory.Status);
                    if (existingEntry != null)
                    {
                        existingEntry.Count++;
                    }
                    else
                    {
                        report.Add(new ProductBackLogReportDTO
                        {
                            epicId = epic.Id,
                            EpicName = epic.Name,
                            Stage = userStory.Status,
                            Count = 1
                        });
                    }
                }
            }
            return report;
        }
        public async Task<IEnumerable<UserStory>> GetUserStories()
        {
            return await userStoryRepo.GetAllUserStories();
        }
    }
}
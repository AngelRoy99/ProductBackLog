﻿using Microsoft.EntityFrameworkCore;
using ProductBacklogManagement.Models;
using ProductBacklogManagement_BLL.DTO;
using ProductBacklogManagement_BLL.Services.Interfaces;
using ProductBacklogManagement_DAL.Repository.Classes;
using ProductBacklogManagements_DAL.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagement_BLL.Services.Classes
{
    public class EpicService : IEpicService
    {
        private readonly IEpicRepository epicRepo;


        public EpicService(IEpicRepository epicRepo)
        {
            this.epicRepo = epicRepo;

        }

        public async Task<int> AddEpicAsync(EpicDTO epicDTO)
        {
            ValidateEpicData(epicDTO);
            var currentDate = DateTime.Today;
            var epic = new Epic
            {
                ProjectCode = epicDTO.ProjectCode,
                SprintId = epicDTO.SprintId,
                Name = epicDTO.Name,
                CreatedOn = currentDate,
                CompletedOn = epicDTO.CompletedOn?.Date,
                Status = epicDTO.Status
            };
            int id=await epicRepo.InsertEpicAsync(epic);
            return id;
        }

        public void ValidateEpicData(EpicDTO epicDTO)
        {
            var allowedStatus = new[] {"InProgress","Done" };

            if (!allowedStatus.Contains(epicDTO.Status))
            {
                throw new Exception("\nEpic status must be one of the following values: " + string.Join(", ", allowedStatus));
            }

        }

        public async Task<Epic> GetEpicByIdAsync(int epicId)
        {
            try
            {
                return await epicRepo.GetByIdAsync(epicId);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error occurred while fetching Epic with ID." + ex.Message);
            }
        }

        public async Task<IEnumerable<Epic>> GetAllEpics()
        {
            return await epicRepo.GetAllEpic();
        }

    }
}

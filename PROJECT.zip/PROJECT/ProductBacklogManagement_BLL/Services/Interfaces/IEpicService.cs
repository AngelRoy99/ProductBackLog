﻿using ProductBacklogManagement.Models;
using ProductBacklogManagement_BLL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagement_BLL.Services.Interfaces
{
    public interface IEpicService
    {
        Task<int> AddEpicAsync(EpicDTO epicDTO);
        Task<Epic> GetEpicByIdAsync(int epicId);
        Task<IEnumerable<Epic>> GetAllEpics();

    }
}

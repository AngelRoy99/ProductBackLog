﻿using ProductBacklogManagement.Models;
using ProductBacklogManagement_BLL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagement_BLL.Services.Interfaces
{
    public interface IUserStoryService
    {
        Task AddUserStoryAsync(UserStoryDTO userStoryDTO, int epicId);
        Task AddUserStoryByEpicIdAsync(List<UserStoryDTO> userStoryDTOList, int epicId);
        Task<UserStory> GetUserStoryByIdAsync(int userStoryId);
        Task<List<UserStory>> GetAllUserStoriesByDeveloperIdAsync(string devId);
        Task<List<UserStory>> DisplayUserStoryByEpicIdAsync(int epicId);
        Task CreateProductBackLogAsync(ProductBackLogDTO productBackLogDTO);
        
        Task<List<ProductBackLogReportDTO>> GetProductBacklogReportByProjectIdAsync(int projectId);

        Task UpdateUserStoryStatusAsync(UpdateStoryDTO updateStoryDTO);
        Task<UserStory> GetUserStoryByIdsAsync(int userStoryId, string developerId);

        Task<IEnumerable<UserStory>> GetUserStories();

    }
}

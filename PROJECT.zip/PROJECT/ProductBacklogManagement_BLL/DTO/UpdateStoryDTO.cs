﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagement_BLL.DTO
{
    public class UpdateStoryDTO
    {
        public int UserStoryId { get; set; }
        public string? Status { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagement_BLL.DTO
{   
    public class ProductBackLogReportDTO
    {   
        public int epicId { get; set; }
        public string EpicName { get; set; }
        public string Stage { get; set; }
        public int Count { get; set; }

        
    }
}


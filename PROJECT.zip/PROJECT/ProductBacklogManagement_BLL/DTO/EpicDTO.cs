﻿using ProductBacklogManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagement_BLL.DTO
{
    public class EpicDTO
    {
        //public int Id { get; set; }

        public int ProjectCode { get; set; }

        public int SprintId { get; set; }

        public string Name { get; set; } = null!;

        //public DateTime? CreatedOn { get; set; } = DateTime.Today;

        public DateTime? CompletedOn { get; set; }

        public string Status { get; set; } = null!;
    }
}

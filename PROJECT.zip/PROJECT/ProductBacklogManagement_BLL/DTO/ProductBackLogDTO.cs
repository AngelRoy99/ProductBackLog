﻿using ProductBacklogManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagement_BLL.DTO
{
    public class ProductBackLogDTO
    {
        public EpicDTO Epic { get; set; } = null!;
        public List<UserStoryDTO> UserStories { get; set; } =null!;
    }
}

﻿using Microsoft.EntityFrameworkCore;
using ProductBacklogManagement.Models;
using ProductBacklogManagements_DAL.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 

namespace ProductBacklogManagements_DAL.Repository.Classes
{ 
    public class UserStoryRepository : IUserStoryRepository
    {
        private readonly BacklogManagementDbContext _dbContext;
        public UserStoryRepository(BacklogManagementDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        
        public async Task<IEnumerable<UserStory>> GetAllUserStories()
        {
            return await _dbContext.UserStories.ToListAsync();
        }

        public async Task<UserStory> GetUserStoryByIdAsync(int userStoryId)
        {
            var userStory = await _dbContext.UserStories.FindAsync(userStoryId);
            return userStory;
        }
        public async Task<List<UserStory>> GetAllUserStoryByEpicIdAsync(int EpicId)
        {
            var userStories = await _dbContext.UserStories.Where(d => d.EpicId == EpicId).ToListAsync();
            return userStories;
        }

        public async Task<List<UserStory>> GetAllUserStoryByDeveloperIdAsync(string devId)
        {
            var userStories = await _dbContext.UserStories.Where(d => d.AssignToDeveloperId == devId).ToListAsync();
            return userStories;
        }

        public async Task<UserStory> GetUserStoryByIdsAsync(int usId, string devId)
        {
           
            var userStories =  _dbContext.UserStories.FirstOrDefault(d => d.AssignToDeveloperId == devId && d.Id == usId);
            if(userStories == null)
            {
                throw new Exception($"User story with id {usId} is not assigned developer id {devId}");
            }
            return userStories;
        }


        public async Task InsertUserStoryAsync(UserStory userStory)
        {

            await _dbContext.UserStories.AddAsync(userStory);
            await _dbContext.SaveChangesAsync();
        }

        public async Task InsertUserStoriesForEpicAsync(List<UserStory> userStories)
        {
            foreach (var item in userStories)
            {
                await InsertUserStoryAsync(item);
            }

        }

        public async Task UpdateUserStoryStatusAsync(int userStoryId, string newStatus)
        {
            var userStory = await _dbContext.UserStories.FindAsync(userStoryId);
            userStory.Status = newStatus;
            await _dbContext.SaveChangesAsync();

        }

    }
        
}

﻿using Microsoft.EntityFrameworkCore;
using ProductBacklogManagement.Models;
using ProductBacklogManagements_DAL;
using ProductBacklogManagements_DAL.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagement_DAL.Repository.Classes
{
    public class EpicRepository : IEpicRepository
    {
        private readonly BacklogManagementDbContext _dbContext;

        public EpicRepository(BacklogManagementDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<int> InsertEpicAsync(Epic epic)
        {
            await _dbContext.Epics.AddAsync(epic);
            await _dbContext.SaveChangesAsync();

            return epic.Id;
        }

        public async Task<Epic> GetByIdAsync(int id)
        {
            {
                var epic = await _dbContext.Epics.FindAsync(id);
                return epic;
            }
        }

        public async Task<List<Epic>> GetEpicsByProjectIdAsync(int projectId)
        {
            var project=await _dbContext.Epics.FirstOrDefaultAsync(e=>e.ProjectCode==projectId);
            if(project == null)
            {
                throw new Exception("Project Id doesn't exists.");
            }
            var epics = await _dbContext.Epics
                .Where(e => e.ProjectCode == projectId).Include(e => e.UserStories).ToListAsync();

            if (epics.Count == 0)
            {
                throw new Exception("No User Story available for backlog report generation.");
            }
            return epics;
        }

        public async Task<IEnumerable<Epic>> GetAllEpic() { 
            return await _dbContext.Epics.ToListAsync();
        }
    }
}
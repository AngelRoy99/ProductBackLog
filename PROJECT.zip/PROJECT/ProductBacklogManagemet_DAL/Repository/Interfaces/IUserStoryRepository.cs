﻿using ProductBacklogManagement.Models;
//using ProductBacklogManagemet_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagements_DAL.Repository.Interfaces
{
    public interface IUserStoryRepository
    {

        Task<IEnumerable<UserStory>> GetAllUserStories();
        Task<UserStory> GetUserStoryByIdAsync(int userStoryId);
        Task<List<UserStory>> GetAllUserStoryByEpicIdAsync(int EpicId);
        Task<List<UserStory>> GetAllUserStoryByDeveloperIdAsync(string devId);
        Task<UserStory> GetUserStoryByIdsAsync(int usId, string devId);
        Task InsertUserStoryAsync(UserStory userStory);
        Task UpdateUserStoryStatusAsync(int userStoryId, string newStatus);
        Task InsertUserStoriesForEpicAsync(List<UserStory> userStories);
    }

}

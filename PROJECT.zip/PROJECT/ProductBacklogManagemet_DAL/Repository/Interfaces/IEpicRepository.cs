﻿using ProductBacklogManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklogManagements_DAL.Repository.Interfaces
{
    public interface IEpicRepository
    {
        Task<Epic> GetByIdAsync(int id);
        Task<int> InsertEpicAsync(Epic epic);
        Task<List<Epic>> GetEpicsByProjectIdAsync(int projectId);
        Task<IEnumerable<Epic>>GetAllEpic();

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ProductBacklogManagement.Models;

public class Epic
{
    public int Id { get; set; }

    public int ProjectCode { get; set; }

    public int SprintId { get; set; }

    public string Name { get; set; } = null!;

    public DateTime CreatedOn { get; set; }  = DateTime.Today;

    public DateTime? CompletedOn { get; set; } = default!;

    public string Status { get; set; } = "InProgress";

    public  ICollection<UserStory> UserStories { get; set; } = new List<UserStory>();
}

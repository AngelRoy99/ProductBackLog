﻿using System;
using System.Collections.Generic;

namespace ProductBacklogManagement.Models;

public class UserStory
{
    public int Id { get; set; }

    public string Title { get; set; }

    public string? UserStoryDetails { get; set; }

    public string? AcceptanceCriteria { get; set; }

    public string Priority { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime? DoneOn { get; set; }

    public string? AssignToDeveloperId { get; set; }

    public int StoryPoints { get; set; }

    public string Status { get; set; }

    public int EpicId { get; set; }

    public virtual Epic Epic { get; set; }
}

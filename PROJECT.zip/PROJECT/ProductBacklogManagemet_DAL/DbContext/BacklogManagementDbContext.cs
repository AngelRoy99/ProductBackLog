﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using ProductBacklogManagement.Models;

namespace ProductBacklogManagements_DAL;

public partial class BacklogManagementDbContext : DbContext
{
    public BacklogManagementDbContext()
    {
    }

    public BacklogManagementDbContext(DbContextOptions<BacklogManagementDbContext> options)
        : base(options)
    {
    }

    public DbSet<Epic> Epics { get; set; }
    public DbSet<UserStory> UserStories { get; set; }


   protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if(!optionsBuilder.IsConfigured) { }

    } 


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Epic>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__EPICs"); 
            entity.ToTable("EPICs");
            entity.Property(e => e.Id)
                  .ValueGeneratedOnAdd()
                  .UseIdentityColumn();

            entity.Property(e => e.ProjectCode)
                .IsRequired();

            entity.Property(e => e.SprintId)
                .IsRequired();

            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.CreatedOn)
                .HasDefaultValue(DateTime.Today)
                .IsRequired();

            entity.Property(e => e.Status)
                .HasMaxLength(20).IsUnicode(false)
                .HasDefaultValue("InProgress");
            entity.HasCheckConstraint("Ch_EpicStatus", "[Status] IN ('InProgress','Done')");
        });


        modelBuilder.Entity<UserStory>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__UserStory");
            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .UseIdentityColumn();

            entity.Property(e => e.Title)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.UserStoryDetails)
                .HasMaxLength(1000)
                .IsUnicode(false);

            entity.Property(e => e.AcceptanceCriteria)
                .HasMaxLength(1000)
                .IsUnicode(false);

            entity.Property(e => e.Priority)
                .HasMaxLength(2)
                .IsUnicode(false);

            entity.Property(e => e.CreatedOn)
                .HasDefaultValue(DateTime.Today)
                .IsRequired();

            entity.Property(e => e.AssignToDeveloperId)
                .HasMaxLength(6)
                .IsUnicode(false);

            entity.Property(e => e.Status)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("New");
            entity.HasCheckConstraint("Ch_UserStoryStatus", "[Status] IN ('New','Planning','Coding','Testing','Done')");
                

            entity.HasOne(d => d.Epic).WithMany(p => p.UserStories)
                .HasForeignKey(d => d.EpicId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserStory_Epic");

        });

        base.OnModelCreating(modelBuilder);
    }
}

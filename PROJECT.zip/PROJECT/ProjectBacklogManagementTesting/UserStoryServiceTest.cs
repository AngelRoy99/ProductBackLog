﻿using Moq;
using ProductBacklogManagement.Models;
using ProductBacklogManagement_BLL.DTO;
using ProductBacklogManagement_BLL.Services.Classes;
using ProductBacklogManagement_BLL.Services.Interfaces;
using ProductBacklogManagements_DAL.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectBacklogManagementTesting
{
    [TestFixture]
    public class UserStoryServiceTest
    {
        private UserStoryService userStoryService;
        private Mock<IUserStoryRepository> userStoryRepoMock;
        private Mock<IEpicRepository> epicRepoMock;
        private Mock<IEpicService> epicServiceMock;

        [SetUp]
        public void SetUp()
        {
            userStoryRepoMock = new Mock<IUserStoryRepository>();
            epicRepoMock = new Mock<IEpicRepository>();
            epicServiceMock = new Mock<IEpicService>();
            userStoryService = new UserStoryService(userStoryRepoMock.Object, epicRepoMock.Object, epicServiceMock.Object);
        }

        [Test]
        public async Task GetProductBacklogReportByProjectIdAsync_ValidProjectId_ReturnsReport()
        {
            // Arrange
            int projectId = 1;
            var epics = new List<Epic>
            {
                new Epic
                {
                    Id = 1,
                    Name = "Epic 1",
                    UserStories = new List<UserStory>
                    {
                        new UserStory { Status = "New" },
                        new UserStory { Status = "InProgress" }
                    }
                },
                new Epic
                {
                    Id = 2,
                    Name = "Epic 2",
                    UserStories = new List<UserStory>
                    {
                        new UserStory { Status = "Done" }
                    }
                }
            };
            epicRepoMock.Setup(repo => repo.GetEpicsByProjectIdAsync(projectId)).ReturnsAsync(epics);

            // Act
            var result = await userStoryService.GetProductBacklogReportByProjectIdAsync(projectId);

            // Assert
            Assert.AreEqual(3, result.Count());
            Assert.AreEqual(1, result.Count(r => r.EpicName == "Epic 1" && r.Stage == "New" && r.Count == 1));
            Assert.AreEqual(1, result.Count(r => r.EpicName == "Epic 1" && r.Stage == "InProgress" && r.Count == 1));
            Assert.AreEqual(1, result.Count(r => r.EpicName == "Epic 2" && r.Stage == "Done" && r.Count == 1));
        }

        [Test]
        public async Task GetUserStories_ReturnsListOfUserStories()
        {
            // Arrange
            var expectedUserStories = new List<UserStory>
            {
                new UserStory { Id = 1, Title = "User Story 1" },
                new UserStory { Id = 2, Title = "User Story 2" }
            };
            userStoryRepoMock.Setup(repo => repo.GetAllUserStories()).ReturnsAsync(expectedUserStories);

            // Act
            var result = await userStoryService.GetUserStories();

            // Assert
            CollectionAssert.AreEqual(expectedUserStories, result);
        }

        [Test]
        public async Task DisplayUserStoryByEpicIdAsync_EpicWithUserStories_ReturnsUserStories()
        {
            // Arrange
            int epicId = 1;
            var userStories = new List<UserStory>
            {
                new UserStory { Id = 1, Title = "User Story 1" },
                new UserStory { Id = 2, Title = "User Story 2" }
            };
            userStoryRepoMock.Setup(repo => repo.GetAllUserStoryByEpicIdAsync(epicId)).ReturnsAsync(userStories);

            // Act
            var result = await userStoryService.DisplayUserStoryByEpicIdAsync(epicId);

            // Assert
            CollectionAssert.AreEqual(userStories, result);
        }

        [Test]
        public async Task DisplayUserStoryByEpicIdAsync_EpicWithoutUserStories_ThrowsException()
        {
            // Arrange
            int epicId = 1;
            userStoryRepoMock.Setup(repo => repo.GetAllUserStoryByEpicIdAsync(epicId)).ReturnsAsync(new List<UserStory>());

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => userStoryService.DisplayUserStoryByEpicIdAsync(epicId));
        }

        [Test]
        public async Task UpdateUserStoryStatusAsync_ValidInput_UpdatesStatus()
        {
            // Arrange
            var updateStoryDto = new UpdateStoryDTO
            {
                UserStoryId = 1,
                Status = "Done"
            };
            var existingUserStory = new UserStory { Id = 1, Title = "Sample User Story" };
            userStoryRepoMock.Setup(repo => repo.GetUserStoryByIdAsync(updateStoryDto.UserStoryId)).ReturnsAsync(existingUserStory);

            // Act
            await userStoryService.UpdateUserStoryStatusAsync(updateStoryDto);

            // Assert
            userStoryRepoMock.Verify(repo => repo.UpdateUserStoryStatusAsync(updateStoryDto.UserStoryId, updateStoryDto.Status), Times.Once);
        }

        [Test]
        public async Task GetAllUserStoriesByDeveloperIdAsync_ValidDeveloperId_ReturnsUserStories()
        {
            // Arrange
            string devId = "DEV123";
            var expectedUserStories = new List<UserStory>
            {
                new UserStory { Id = 1, Title = "User Story 1" },
                new UserStory { Id = 2, Title = "User Story 2" }
            };
            userStoryRepoMock.Setup(repo => repo.GetAllUserStoryByDeveloperIdAsync(devId)).ReturnsAsync(expectedUserStories);

            // Act
            var result = await userStoryService.GetAllUserStoriesByDeveloperIdAsync(devId);

            // Assert
            CollectionAssert.AreEqual(expectedUserStories, result);
            userStoryRepoMock.Verify(repo => repo.GetAllUserStoryByDeveloperIdAsync(devId), Times.Once);
        }

        [Test]
        public async Task GetAllUserStoriesByDeveloperIdAsync_InvalidDeveloperId_ThrowsException()
        {
            // Arrange
            string devId = "DEV456";
            userStoryRepoMock.Setup(repo => repo.GetAllUserStoryByDeveloperIdAsync(devId)).ReturnsAsync(new List<UserStory>());

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => userStoryService.GetAllUserStoriesByDeveloperIdAsync(devId));
        }

        [Test]
        public async Task GetUserStoryByIdsAsync_ValidInput_ReturnsUserStory()
        {
            // Arrange
            int userStoryId = 123;
            string developerId = "DEV456";
            var expectedUserStory = new UserStory { Id = userStoryId, Title = "Sample User Story" };
            userStoryRepoMock.Setup(repo => repo.GetUserStoryByIdsAsync(userStoryId, developerId)).ReturnsAsync(expectedUserStory);

            // Act
            var result = await userStoryService.GetUserStoryByIdsAsync(userStoryId, developerId);

            // Assert
            Assert.AreEqual(expectedUserStory, result);
            userStoryRepoMock.Verify(repo => repo.GetUserStoryByIdsAsync(userStoryId, developerId), Times.Once);
        }

        [Test]
        public async Task GetUserStoryByIdsAsync_InvalidInput_ThrowsException()
        {
            // Arrange
            int userStoryId = 456;
            string developerId = "DEV789";
            userStoryRepoMock.Setup(repo => repo.GetUserStoryByIdsAsync(userStoryId, developerId)).ReturnsAsync((UserStory)null);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => userStoryService.GetUserStoryByIdsAsync(userStoryId, developerId));
        }

        [Test]
        public async Task GetUserStoryByIdAsync_ValidUserStoryId_ReturnsUserStory()
        {
            // Arrange
            int userStoryId = 123;
            var expectedUserStory = new UserStory { Id = userStoryId, Title = "Sample User Story" };
            userStoryRepoMock.Setup(repo => repo.GetUserStoryByIdAsync(userStoryId)).ReturnsAsync(expectedUserStory);

            // Act
            var result = await userStoryService.GetUserStoryByIdAsync(userStoryId);

            // Assert
            Assert.AreEqual(expectedUserStory, result);
            userStoryRepoMock.Verify(repo => repo.GetUserStoryByIdAsync(userStoryId), Times.Once);
        }

        [Test]
        public void AddUserStoryByEpicIdAsync_EmptyList_ThrowsException()
        {
            // Arrange
            var userStoryDtoList = new List<UserStoryDTO>();
            int epicId = 1;

            // Act & Assert
            Assert.ThrowsAsync<ArgumentNullException>(() => userStoryService.AddUserStoryByEpicIdAsync(userStoryDtoList, epicId));
        }
    }
}

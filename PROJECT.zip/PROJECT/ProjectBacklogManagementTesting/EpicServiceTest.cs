﻿
using NUnit.Framework;
using Moq;
using ProductBacklogManagement_BLL.Services.Classes;
using ProductBacklogManagement_BLL.Services.Interfaces;
using ProductBacklogManagement.Models;
using ProductBacklogManagement_BLL.DTO;
using System;
using ProductBacklogManagements_DAL.Repository.Interfaces;

namespace ProjectBacklogManagementTesting
{
    [TestFixture]
    public class EpicServiceTest
    {
        private EpicService epicService;
        private Mock<IEpicRepository> epicRepoMock;

        [SetUp]
        public void SetUp()
        {
            epicRepoMock = new Mock<IEpicRepository>();
            epicService = new EpicService(epicRepoMock.Object);
        }

        [Test]
        public async Task AddEpicAsync_ValidEpic_ReturnsEpicId()
        {
            // Arrange
            var epicDTO = new EpicDTO
            {
                ProjectCode = 100,
                SprintId = 1,
                Name = "Sample Epic",
                Status = "InProgress"
            };

            epicRepoMock.Setup(repo => repo.InsertEpicAsync(It.IsAny<Epic>()))
                .ReturnsAsync(123); 

            // Act
            var result = await epicService.AddEpicAsync(epicDTO);

            // Assert
            Assert.AreEqual(123, result);
            epicRepoMock.Verify(repo => repo.InsertEpicAsync(It.IsAny<Epic>()), Times.Once);
        }

        [Test]
        public void ValidateEpicData_ValidStatus_NoExceptionThrown()
        {
            // Arrange
            var epicDTO = new EpicDTO
            {
                Status = "InProgress"
            };

            // Act & Assert
            Assert.DoesNotThrow(() => epicService.ValidateEpicData(epicDTO));
        }

        [Test]
        public void ValidateEpicData_InvalidStatus_ThrowsException()
        {
            // Arrange
            var epicDTO = new EpicDTO
            {
                Status = "InvalidStatus"
            };

            // Act & Assert
            Assert.Throws<Exception>(() => epicService.ValidateEpicData(epicDTO));
        }

        [Test]
        public async Task GetEpicByIdAsync_ValidId_ReturnsEpic()
        {
            // Arrange
            int epicId = 123;
            var expectedEpic = new Epic { Id = epicId, Name = "Sample Epic" };
            epicRepoMock.Setup(repo => repo.GetByIdAsync(epicId)).ReturnsAsync(expectedEpic);

            // Act
            var result = await epicService.GetEpicByIdAsync(epicId);

            // Assert
            Assert.AreEqual(expectedEpic, result);
            epicRepoMock.Verify(repo => repo.GetByIdAsync(epicId), Times.Once);
        }

        [Test]
        public async Task GetAllEpics_ReturnsListOfEpics()
        {
            // Arrange
            var expectedEpics = new List<Epic>
            {
                new Epic { Id = 1, Name = "Epic 1" },
                new Epic { Id = 2, Name = "Epic 2" }
            };
            epicRepoMock.Setup(repo => repo.GetAllEpic()).ReturnsAsync(expectedEpics);

            // Act
            var result = await epicService.GetAllEpics();

            // Assert
            CollectionAssert.AreEqual(expectedEpics, result);
            epicRepoMock.Verify(repo => repo.GetAllEpic(), Times.Once);
        }
    }
}

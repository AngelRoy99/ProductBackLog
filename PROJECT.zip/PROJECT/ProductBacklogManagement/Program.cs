using Microsoft.EntityFrameworkCore;
using ProductBacklogManagement_BLL.Services.Classes;
using ProductBacklogManagement_BLL.Services.Interfaces;
using ProductBacklogManagement_DAL.Repository.Classes;
using ProductBacklogManagement_BLL.Services.Interfaces;
using ProductBacklogManagements_DAL;
using ProductBacklogManagements_DAL.Repository.Classes;
using ProductBacklogManagements_DAL.Repository.Interfaces;
using log4net.Config;
using log4net;
using System.Diagnostics.Contracts;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<BacklogManagementDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("pbm_cs")));
builder.Services.AddScoped<IEpicRepository, EpicRepository>();
builder.Services.AddScoped<IUserStoryRepository, UserStoryRepository>();
builder.Services.AddScoped<IEpicService, EpicService>();
builder.Services.AddScoped<IUserStoryService,UserStoryService>();
builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

XmlConfigurator.Configure(new FileInfo("log4net.config"));
builder.Services.AddSingleton(LogManager.GetLogger(typeof(Program)));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors(policy=>policy.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
app.UseAuthorization();

app.MapControllers();

app.Run();

﻿using log4net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using ProductBacklogManagement.Models;
using ProductBacklogManagement_BLL.DTO;
using ProductBacklogManagement_BLL.Services.Classes;
using ProductBacklogManagement_BLL.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Threading.Tasks;

namespace ProductBacklogManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductBacklogController : ControllerBase
    {
        private readonly IEpicService epicService;
        private readonly IUserStoryService userStoryService;
        private readonly ILog logger;

        public ProductBacklogController(IEpicService epicService, IUserStoryService userStoryService, ILog logger)
        {
            this.epicService = epicService;
            this.userStoryService = userStoryService;
            this.logger = logger;
        }


        [HttpPost("create/epic")]
        public async Task<IActionResult> CreateEpicAsync(EpicDTO epicDTO)
        {
            try
            {
                await epicService.AddEpicAsync(epicDTO); 
                return Ok();
            }

            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return StatusCode(500, "An error occurred while inserting. " + ex.Message);
            }
        }


        [HttpPost("createUserstoryByepicId/{epicId}")]
        public async Task<IActionResult> CreateUserStoryByEpicId(UserStoryDTO userStoryDTO, int epicId)
        {
            try
            {
                await userStoryService.AddUserStoryAsync(userStoryDTO, epicId); 
                return Ok();
            }

            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return StatusCode(500,"An error occurred while inserting User Story:\n" + ex.Message);
            }
        }


        [HttpPost("createEpicwithUserstory")]
        public async Task<IActionResult> CreateProductBackLog(ProductBackLogDTO productBackLogDTO)
        {
            if (productBackLogDTO == null)
            {
                return BadRequest("Invalid Input Data.");
            }

            try
            {
                await userStoryService.CreateProductBackLogAsync(productBackLogDTO); 
                return Ok();
            }

            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return StatusCode(500, "An error occurred: Insert Operation Failed\n" + ex.Message);
            }
        }

        //DisplayUserStoryByEpicIdAsync
        [HttpGet("userstoriesByepicId/{epicid}")]
        public async Task<IActionResult> DisplayUserStoryByEpicIdAsync(int epicid)
        {
            if (epicid == null)
            {
                return BadRequest("Provide Epic ID");
            }
            else
            {
                try
                {
                    var userstorybyepic = await userStoryService.DisplayUserStoryByEpicIdAsync(epicid);
                    return Ok(userstorybyepic);
                }
                catch (Exception ex)
                {
                    logger.Error(ex.Message);
                    return StatusCode(500, "An error occurred while fetching User Stories:\n" + ex.Message);
                }
            }
        }

        [HttpGet("userstories/{devId}")]
        public async Task<IActionResult> GetUserStoriesAssignedToDeveloper(string devId)
        {
            if (devId == null)
            {
                return BadRequest("Provide developer ID.");
            }
            else 
            {
                try
                {
                    var userstoriesAssignedToDev = await userStoryService.GetAllUserStoriesByDeveloperIdAsync(devId);
                    return Ok(userstoriesAssignedToDev);
                }
                catch (Exception ex)
                {
                    logger.Error(ex.Message);
                    return StatusCode(500, "An error occurred while fetching User Stories:\n" + ex.Message);
                }
            }

        }

        [HttpPut("updatestory")]
        public async Task<IActionResult> UpdateUserStoriesStatus(UpdateStoryDTO updateStoryDTO)
        {
            try
            {
                if (updateStoryDTO.Status == null)
                {
                    return BadRequest("Status is required !");
                }
                await userStoryService.UpdateUserStoryStatusAsync(updateStoryDTO); 
                return Ok();
            }

            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return StatusCode(500, "An error occurred while updating User Story status:\n" + ex.Message);
            }
        }


        [HttpGet("report/{projectCode}")]
        public async Task<ActionResult<List<ProductBackLogReportDTO>>> GetProductBacklogReport(int projectCode)
        {
            try
            {
                var report = await userStoryService.GetProductBacklogReportByProjectIdAsync(projectCode);
                return Ok(report);
            }

            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return StatusCode(500, "An error occurred while fetching Product Backlog report: \n" + ex.Message);
            }
        }


        [HttpGet("userstories/{userStoryId:int}")]
        public async Task<IActionResult> GetUserStory(int userStoryId)
        {
            try
            {
                var userStory = await userStoryService.GetUserStoryByIdAsync(userStoryId);

                if (userStory == null)
                {
                    return NotFound();
                }
                return Ok(userStory);
            }

            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return StatusCode(500, "An error occurred while fetching User Story:\n" + ex.Message);
            }

        }

        [HttpGet("allEpics")]
        public async Task<ActionResult<IEnumerable<Epic>>> GetAllEpics()
        {
            try
            {
                var epics = await epicService.GetAllEpics();
                return Ok(epics);
            }

            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return StatusCode(500, "An error occurred while fetching Product Backlog report: \n" + ex.Message);
            }
        }


        [HttpGet("getUserstoriesByIds")]
        public async Task<IActionResult> GetUserStoryByIdsAsync(int userStoryId, string developerId)
        {   
            try
            {
                var userStories = await userStoryService.GetUserStoryByIdsAsync(userStoryId, developerId);
                return Ok(userStories);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return StatusCode(500, "An error occurred while fetching Product Backlog report: \n" + ex.Message);
            }

        }

        [HttpGet("allUserStories")]
        public async Task<ActionResult<IEnumerable<Epic>>> GetAllUserStories()
        {
            try
            {
                var userstories = await userStoryService.GetUserStories();
                return Ok(userstories);
            }

            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return StatusCode(500, "An error occurred while fetching Product Backlog report: \n" + ex.Message);
            }
        }

    }
}


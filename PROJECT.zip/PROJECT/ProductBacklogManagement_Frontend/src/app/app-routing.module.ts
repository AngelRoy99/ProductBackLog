import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DevelopersComponent } from './Components/developers/developers.component';
import { ProductOwnersComponent } from './Components/product-owners/product-owners.component';
import { HomeComponent } from './Components/home/home.component';
import { ContactComponent } from './Components/contact/contact.component';
import { AboutComponent } from './Components/about/about.component';
import { PageNotFoundComponent } from './Components/page-not-found/page-not-found.component';
import { CreateEpicComponent } from './Components/create-epic/create-epic.component';
import { CreateUserStoryComponent } from './Components/create-user-story/create-user-story.component';
import { DisplayProductBacklogReportComponent } from './Components/display-product-backlog-report/display-product-backlog-report.component';
import { UserStoriesListComponent } from './Components/user-stories-list/user-stories-list.component';
import { UserStoryDetailsComponent } from './Components/user-story-details/user-story-details.component';
import { ChangeUserStoryStatusComponent } from './Components/change-user-story-status/change-user-story-status.component';
import { DisplayEpicComponent } from './Components/display-epic/display-epic.component';
import { DisplayUserStoryComponent } from './Components/display-user-story/display-user-story.component';

const routes: Routes = [
  {path:'', redirectTo:'home', pathMatch:'full'},
  {path: 'home', component:HomeComponent},
  {path: 'about', component:AboutComponent},
  {path: 'contact', component:ContactComponent},
	{path: 'productowners', component:ProductOwnersComponent},
  {path: 'developers', component:DevelopersComponent},
  {path: 'createepic', component:CreateEpicComponent},
  {path: 'createuserstory', component:CreateUserStoryComponent},
  {path: 'displayepic', component:DisplayEpicComponent},
  {path: 'displayuserstory/:epicId', component:DisplayUserStoryComponent},
  {path: 'displayproductbacklogreport', component:DisplayProductBacklogReportComponent},
  {path: 'userstorylist', component:UserStoriesListComponent},
  {path: 'userstorydetails', component:UserStoryDetailsComponent},
  {path: 'changeuserstorystatus', component:ChangeUserStoryStatusComponent},
  {path: '**', component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

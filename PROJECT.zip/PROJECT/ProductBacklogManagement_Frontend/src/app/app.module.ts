import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { UserStoriesListComponent } from './Components/user-stories-list/user-stories-list.component';
import { UserStoryDetailsComponent } from './Components/user-story-details/user-story-details.component';
import { UseStoryReportComponent } from './Components/use-story-report/use-story-report.component';
import { HeaderComponent } from './Components/header/header.component';
import { FooterComponent } from './Components/footer/footer.component';
import { HomeComponent } from './Components/home/home.component';
import { DevelopersComponent } from './Components/developers/developers.component';
import { ProductOwnersComponent } from './Components/product-owners/product-owners.component';
import { PageNotFoundComponent } from './Components/page-not-found/page-not-found.component';
import { ReactiveFormsModule } from '@angular/forms';
import { CreateUserStoryComponent } from './Components/create-user-story/create-user-story.component';
import { CreateEpicComponent } from './Components/create-epic/create-epic.component';
import { AboutComponent } from './Components/about/about.component';
import { ContactComponent } from './Components/contact/contact.component';
import { DisplayProductBacklogReportComponent } from './Components/display-product-backlog-report/display-product-backlog-report.component';
import { ChangeUserStoryStatusComponent } from './Components/change-user-story-status/change-user-story-status.component';
import { DisplayEpicComponent } from './Components/display-epic/display-epic.component';
import { DisplayUserStoryComponent } from './Components/display-user-story/display-user-story.component';
import { HttpClientModule } from '@angular/common/http';
import { ApiService } from './Service/api.service';

@NgModule({
  declarations: [
    AppComponent,
    UserStoriesListComponent,
    UserStoryDetailsComponent,
    UseStoryReportComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    DevelopersComponent,
    ProductOwnersComponent,
    PageNotFoundComponent,
    CreateUserStoryComponent,
    CreateEpicComponent,
    AboutComponent,
    ContactComponent,
    DisplayProductBacklogReportComponent,
    ChangeUserStoryStatusComponent,
    DisplayEpicComponent,
    DisplayUserStoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    provideClientHydration(),
    ApiService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

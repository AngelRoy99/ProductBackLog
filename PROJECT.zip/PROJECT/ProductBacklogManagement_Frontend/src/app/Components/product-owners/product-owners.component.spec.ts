import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductOwnersComponent } from './product-owners.component';

describe('ProductOwnersComponent', () => {
  let component: ProductOwnersComponent;
  let fixture: ComponentFixture<ProductOwnersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProductOwnersComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ProductOwnersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

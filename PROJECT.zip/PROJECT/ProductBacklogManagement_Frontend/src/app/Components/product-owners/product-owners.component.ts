import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-owners',
  templateUrl: './product-owners.component.html',
  styleUrl: './product-owners.component.css'
})
export class ProductOwnersComponent {
  constructor(private router:Router){}
  createEpic(){
    this.router.navigate(['createepic']);
  }
  createUserStory(){
    this.router.navigate(['createuserstory']);
  }
  displayProductBacklog(){
    this.router.navigate(['displayepic']);
  }
  displayProductBacklogReport(){
    this.router.navigate(['displayproductbacklogreport']);
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-use-story-report',
  templateUrl: './use-story-report.component.html',
  styleUrl: './use-story-report.component.css'
})
export class UseStoryReportComponent {

}

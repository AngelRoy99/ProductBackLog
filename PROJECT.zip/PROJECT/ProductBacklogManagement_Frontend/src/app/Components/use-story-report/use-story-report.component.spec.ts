import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UseStoryReportComponent } from './use-story-report.component';

describe('UseStoryReportComponent', () => {
  let component: UseStoryReportComponent;
  let fixture: ComponentFixture<UseStoryReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UseStoryReportComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UseStoryReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../Service/api.service';

@Component({
  selector: 'app-user-story-details',
  templateUrl: './user-story-details.component.html',
  styleUrl: './user-story-details.component.css'
})
export class UserStoryDetailsComponent {
  userStoryId:any;
  devId : any;
  usDetails:any;
  userstorydetailsbyidsForm=new FormGroup({
  userStoryId: new FormControl('',[Validators.required]),
  devId:new FormControl('',[Validators.required])
  });
  constructor(private router: Router, private api:ApiService) {}
  
  search(){
    console.log(this.userstorydetailsbyidsForm.value.userStoryId,this.userstorydetailsbyidsForm.value.devId);
    this.api.getAllUserStoriesByIds(this.userstorydetailsbyidsForm.value.userStoryId,this.userstorydetailsbyidsForm.value.devId).subscribe({      
      next: (response:any) => {
      this.usDetails = response;
      console.log(response);
      this.router.navigate(['userstorydetails']);
      },
      error: (err) => {
        alert(err.error);
        //alert("An error occurred while fetching user story details");
        //this.router.navigate(['userstorydetails']);
      }
    });
  }
  goBack(){
    this.router.navigate(['developers']);
  }
}

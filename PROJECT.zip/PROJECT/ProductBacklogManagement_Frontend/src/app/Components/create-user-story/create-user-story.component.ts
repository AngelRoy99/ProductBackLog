import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../Service/api.service';

@Component({
  selector: 'app-create-user-story',
  templateUrl: './create-user-story.component.html',
  styleUrl: './create-user-story.component.css'
})

export class CreateUserStoryComponent {

  // userStoryId: new FormControl({ value: '', disabled: true }),
  createUserStoryForm = new FormGroup({
    epicId: new FormControl('', [
      Validators.required,
      Validators.maxLength(10),
    ]),
    title: new FormControl('', [
      Validators.required,
      Validators.minLength(10),
    ]),
    userStoryDetails: new FormControl('', [
      Validators.required,
      Validators.minLength(10), // 1000
    ]),
    acceptanceCriteria: new FormControl('', [
      Validators.required,
      Validators.minLength(10), // 1000
    ]),
    priority: new FormControl('', [
      Validators.required,
      // Validators.maxLength(2),
    ]),
    // createdOn: new FormControl({ value:'', disabled: true }),
    doneOn: new FormControl(''),
    assignToDeveloperId: new FormControl('', [
      Validators.required,
      Validators.maxLength(6),
    ]),
    storyPoints: new FormControl('', [
      Validators.required,
      Validators.min(1),
      Validators.max(20),
    ]),
    status: new FormControl('New', [
      Validators.required,
    ]),
  });
  // validateWordCount(minWords: number) {
  //   return (control) => {
  //     const value = control.value;
  //     const wordCount = value ? value.trim().split(/\s+/).length : 0;
  //     return wordCount >= minWords ? null : { minlength: { requiredWords: minWords, actualWords: wordCount } };
  //   };

  
constructor(private router:Router, private api: ApiService) {}

  get f() {
    return this.createUserStoryForm.controls;
  }
    back(){
      this.router.navigate(['productowners']);
    }
    saveUserstory(){
    console.log(this.createUserStoryForm.value);
    var data = this.createUserStoryForm.value;
      if(data.doneOn){
        data.doneOn=new Date(data.doneOn).toJSON();
      } 
      this.api.postUserStory(data,data.epicId).subscribe({
        next: (response) => {
          console.log(response);
          this.router.navigate(['productowners']);
        },
        error: (err) => {
          alert(err.error)
        },
        complete: () => {
          alert("User story Added Successfully");
        }
      }) ;           
  }
}


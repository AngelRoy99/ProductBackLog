import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ApiService } from '../../Service/api.service';

@Component({
  selector: 'app-user-stories-list',
  templateUrl: './user-stories-list.component.html',
  styleUrl: './user-stories-list.component.css'
})

export class UserStoriesListComponent {

  listOfUs : any;
  getUserByDevForm=new FormGroup({
    devId:new FormControl('',[Validators.required])
  });

  constructor(private router: Router, private api:ApiService) {}
  
  search(){
    this.api.getAllUserStoriesByDevId(this.getUserByDevForm.value.devId).subscribe({      
      next: (response:any) => {
       this.listOfUs= response;
      console.log(response);
      },
      error: (err) => {
        //alert("An error occurred while fetching user story details");
        alert(err.error);
        this.router.navigate(['developers']);
      }
    });
  }
  goBack(){
    this.router.navigate(['developers']);
  }
}

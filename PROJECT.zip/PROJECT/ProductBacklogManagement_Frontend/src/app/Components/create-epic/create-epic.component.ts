import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../Service/api.service';

@Component({
  selector: 'app-create-epic',
  templateUrl: './create-epic.component.html',
  styleUrl: './create-epic.component.css'
})

export class CreateEpicComponent {
  createEpicForm = new FormGroup({
    // epicId: new FormControl({ value: '', disabled: true }),

    projectCode: new FormControl('', [
      Validators.required,
      Validators.maxLength(10)
    ]),
    sprintId: new FormControl('', [
      Validators.required,
      Validators.maxLength(10)
    ]),
    name: new FormControl('', [
      Validators.required,
      Validators.maxLength(50),
    ]),
    // createdOn: new FormControl({ value:'', disabled: true }),

    completedOn: new FormControl(''),

    status: new FormControl('InProgress', [
      Validators.required
    ]),
  });


  get f() {
    return this.createEpicForm.controls;
  }
  constructor(private router: Router,private api : ApiService) {}


  saveEpic() {
    var data = this.createEpicForm.value;
    if(data.completedOn){
      data.completedOn=new Date(data.completedOn).toJSON();
    } 
    
    this.api.postEpic(data).subscribe({
      next: (response) => {
        console.log(response);
        this.router.navigate(['productowners']);
      },
      error: (error) => {
        alert("An error occurred while adding the epic'");
        this.router.navigate(['createepic']);
      },
      complete: () => {
        alert("Epic Added Successfully");
        //this.router.navigate(['createepic']);
      }
    })
  }
 
  back(){
    this.router.navigate(['productowners']);
  }
  
}

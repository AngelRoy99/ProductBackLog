import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { ApiService } from '../../Service/api.service';

@Component({
  selector: 'app-display-product-backlog-report',
  templateUrl: './display-product-backlog-report.component.html',
  styleUrl: './display-product-backlog-report.component.css'
})
export class DisplayProductBacklogReportComponent {
  productBacklogReport : any;
  
  getBacklogReportForm=new FormGroup({
    projectCode: new FormControl('',[Validators.required])
  });

  constructor(private router: Router, private api:ApiService) {}

  search() {
    this.api.getProductBacklogReport(this.getBacklogReportForm.value.projectCode).subscribe({
      next: (response: any) => {
        this.productBacklogReport = response;
      },
      error: (err) => {
        alert(err.error);
        this.router.navigate(['productowners']);
      }
    });

  }
 back(){
  this.router.navigate(['productowners']);
 }
}

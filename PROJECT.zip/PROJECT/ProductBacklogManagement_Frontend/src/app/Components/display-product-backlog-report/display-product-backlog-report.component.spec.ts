import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayProductBacklogReportComponent } from './display-product-backlog-report.component';

describe('DisplayProductBacklogReportComponent', () => {
  let component: DisplayProductBacklogReportComponent;
  let fixture: ComponentFixture<DisplayProductBacklogReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DisplayProductBacklogReportComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DisplayProductBacklogReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { ActivatedRoute, ParamMap, Route } from '@angular/router';
import { Router } from '@angular/router';


@Component({
  selector: 'app-developers',
  templateUrl: './developers.component.html',
  styleUrl: './developers.component.css'
})

export class DevelopersComponent {

   constructor(private router:Router){}

  listOfUserStoryAssigned(){
    this.router.navigate(['userstorylist']);
  }
  changeStatus(){
    this.router.navigate(['changeuserstorystatus']);
  }
  userStoryDetails(){
    this.router.navigate(['userstorydetails']);
  }
}

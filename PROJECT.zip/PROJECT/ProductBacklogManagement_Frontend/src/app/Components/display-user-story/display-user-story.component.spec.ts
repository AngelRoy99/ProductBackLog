import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayUserStoryComponent } from './display-user-story.component';

describe('DisplayUserStoryComponent', () => {
  let component: DisplayUserStoryComponent;
  let fixture: ComponentFixture<DisplayUserStoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DisplayUserStoryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DisplayUserStoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

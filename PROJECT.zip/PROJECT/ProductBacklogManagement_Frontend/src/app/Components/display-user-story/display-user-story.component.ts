import { Component } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ApiService } from '../../Service/api.service';

@Component({
  selector: 'app-display-user-story',
  templateUrl: './display-user-story.component.html',
  styleUrl: './display-user-story.component.css'
})


export class DisplayUserStoryComponent {
  epicid: any;
  userstory: any;
  constructor(private router: Router, private route:ActivatedRoute,private api:ApiService) {}

  ngOnInit():void{
    this.route.paramMap.subscribe({
      next:(params:ParamMap)=>{
        this.epicid=params.get('epicId');
      }
    });

    this.api.getAllUserStories(this.epicid).subscribe({      
      next: (response:any) => {
        this.userstory=response;
        console.log(response);
      },
      error:(err)=>{
        alert(err.error);
        this.router.navigate(['displayepic']);
      }
    });
  }
  goBack(){
    this.router.navigate(['displayepic']);
  }
}

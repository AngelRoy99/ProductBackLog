import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeUserStoryStatusComponent } from './change-user-story-status.component';

describe('ChangeUserStoryStatusComponent', () => {
  let component: ChangeUserStoryStatusComponent;
  let fixture: ComponentFixture<ChangeUserStoryStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChangeUserStoryStatusComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ChangeUserStoryStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

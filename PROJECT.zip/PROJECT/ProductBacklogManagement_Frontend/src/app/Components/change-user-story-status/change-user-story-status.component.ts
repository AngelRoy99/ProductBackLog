import { Component } from '@angular/core';
import {Router } from '@angular/router';
import { ApiService } from '../../Service/api.service';

@Component({
  selector: 'app-change-user-story-status',
  templateUrl: './change-user-story-status.component.html',
  styleUrl: './change-user-story-status.component.css'
})
export class ChangeUserStoryStatusComponent {
  userStory: any;
  constructor(private router: Router, private api: ApiService) {
  }
 
  ngOnInit(): void {
    this.api.getAllUserStory().subscribe({
      next: (response: any) => {
        this.userStory = response;
      },
      error: (error: any) => {
        console.error('Error fetching user story:', error);
      }
    });
  }
  fetchUserStory(){
    this.api.getAllUserStory().subscribe({
      next: (response: any) => {
        this.userStory = response;
      }
  })
  }

  updateStatus(id:any,status:any): void {
    
    switch (status) {
      case 'New':
        this.callApi({userStoryId:id,
        status: "Planning"});
        break;
      case 'Planning':
        this.callApi({userStoryId:id,
          status: "Coding"});
        break;
      case 'Coding':
        this.callApi({userStoryId:id,
          status: "Testing"});
        break;
      case 'Testing':
        this.callApi({userStoryId:id,
          status: "Done"});
       
        break;
      default:
        alert("Final Stage");
        break;
    }
    
  }
  

  callApi(obj:any){
      this.api.updateUserStoryStatus(obj).subscribe({
        next: (response: any) => {
          this.userStory=response;
          this.fetchUserStory();
        },
        error: (error: any) => {
          console.error('Error fetching user story:', error);
        }
      });
      
  }
  goBack(){
    this.router.navigate(['developers']);
  }
}
  
  

  

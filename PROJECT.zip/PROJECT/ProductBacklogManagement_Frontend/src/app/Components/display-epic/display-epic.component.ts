import { Component} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../../Service/api.service';

@Component({
  selector: 'app-display-epic',
  templateUrl: './display-epic.component.html',
  styleUrl: './display-epic.component.css'
})

export class DisplayEpicComponent {
  epic : any;
  
  constructor(private router: Router, private api : ApiService)  {}
  ngOnInit(){
    this.api.getAllEpics().subscribe({      
      next: (response:any) => {
      this.epic=response;
      console.log(response)
    }
    });
  }

  displayUserstory(epicId:any){
    console.log(epicId);
    this.router.navigate(['displayuserstory/',epicId]);
  }
  goBack(){
    this.router.navigate(['productowners']);
  }
}
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DisplayEpicComponent } from './display-epic.component';

describe('DisplayEpicComponent', () => {
  let component: DisplayEpicComponent;
  let fixture: ComponentFixture<DisplayEpicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DisplayEpicComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DisplayEpicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

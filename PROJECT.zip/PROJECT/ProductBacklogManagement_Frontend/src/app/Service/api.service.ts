import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ApiService {

  constructor(private http : HttpClient) {}
    handleError(handleError:HttpErrorResponse){
      return handleError.message;
    }
    postEpic(epicDetails : any): Observable <any>{
        return this.http.post<any>('https://localhost:44308/api/ProductBacklog/create/epic',epicDetails);
        
    }
    postUserStory(userstoryDetails : any, epicId:any): Observable <any>{
      return this.http.post<any>(`https://localhost:44308/api/ProductBacklog/createUserstoryByepicId/${epicId}`,userstoryDetails);
      
    }
    getAllEpics(): Observable <any>{
      return this.http.get<any>('https://localhost:44308/api/ProductBacklog/allEpics');
      
    }
    
    getAllUserStories(epicId:any): Observable <any>{
      return this.http.get<any>(`https://localhost:44308/api/ProductBacklog/userstoriesByepicId/${epicId}`);
      
    }

    getProductBacklogReport(projectCode:any): Observable <any>{
      return this.http.get<any>(`https://localhost:44308/api/ProductBacklog/report/${projectCode}`);
      
    }

    getAllUserStoriesByDevId(devId:any): Observable<any>{
      return this.http.get<any>(`https://localhost:44308/api/ProductBacklog/userstories/${devId}`);
      
    }
    
    getAllUserStoriesByIds(userStoryId:any,developerId:any): Observable <any>{
      return this.http.get<any>(`https://localhost:44308/api/ProductBacklog/getUserstoriesByIds?userStoryId=${userStoryId}&developerId=${developerId}`);
      
    }

    getAllUserStory(): Observable <any>{
      return this.http.get<any>(`https://localhost:44308/api/ProductBacklog/allUserStories`);
      
    }
    updateUserStoryStatus(userStory:any): Observable <any>{
      return this.http.put<any>('https://localhost:44308/api/ProductBacklog/updatestory',userStory);
    }
}

  

